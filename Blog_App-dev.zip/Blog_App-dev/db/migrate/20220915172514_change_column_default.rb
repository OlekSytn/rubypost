class ChangeColumnDefault < ActiveRecord::Migration[7.0]
  def change
    change_column_default(:members, :post_counter, 0)
    change_column_default(:posts, :comments_counter, 0)
    change_column_default(:posts, :likes_counter, 0)
  end
end
