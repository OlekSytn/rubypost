FactoryGirl.define do
  factory :rating do
    
  end
end
