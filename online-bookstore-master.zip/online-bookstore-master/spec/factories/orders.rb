FactoryGirl.define do
  factory :order do
    
  end
end
