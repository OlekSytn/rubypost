FactoryGirl.define do
  factory :opinion do
    
  end
end
