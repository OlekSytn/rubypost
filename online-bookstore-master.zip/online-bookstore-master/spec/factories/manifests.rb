FactoryGirl.define do
  factory :manifest do
    
  end
end
